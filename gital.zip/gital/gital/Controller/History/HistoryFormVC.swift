//
//  HistoryFormVC.swift
//  gital
//
//  Created by xiao long on 2020/7/10.
//  Copyright © 2020 Dan Jin. All rights reserved.
//

import UIKit

class HistoryFormVC: UIViewController {

    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

}
